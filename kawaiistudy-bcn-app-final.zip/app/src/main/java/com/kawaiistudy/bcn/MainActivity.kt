package com.kawaiistudy.bcn

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var currentLangIndex = 0 // 0: ES, 1: CA, 2: EN
    private val languages = listOf("es", "ca", "en")
    private var currentMascot = "🐼 Red Panda"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtResponse = findViewById<TextView>(R.id.txtCoachResponse)
        val inputQuery = findViewById<EditText>(R.id.inputUserQuery)
        val btnSend = findViewById<Button>(R.id.btnSend)
        val btnRedPanda = findViewById<Button>(R.id.btnRedPanda)
        val btnGiraffe = findViewById<Button>(R.id.btnGiraffe)
        val btnLang = findViewById<Button>(R.id.btnLang)

        updateUIForLanguage(txtResponse, inputQuery, btnSend, btnLang)

        btnRedPanda.setOnClickListener {
            currentMascot = "🐼 Red Panda"
            txtResponse.text = when (languages[currentLangIndex]) {
                "es" -> "🐼 ¡Mascota cambiada a Panda Rojo (perfil de Olivia)! ¿Qué vamos a estudiar hoy?"
                "ca" -> "🐼 Mascota canviada a Panda Roig (perfil d'Olivia)! Què estudiarem avui?"
                else -> "🐼 Mascot set to Red Panda (Olivia's profile)! What are we studying today?"
            }
        }

        btnGiraffe.setOnClickListener {
            currentMascot = "🦒 Giraffe"
            txtResponse.text = when (languages[currentLangIndex]) {
                "es" -> "🦒 ¡Mascota cambiada a Jirafa (perfil de Ingrid)! ¿Qué tema repasamos?"
                "ca" -> "🦒 Mascota canviada a Girafa (perfil de l'Ingrid)! Quin tema repassem?"
                else -> "🦒 Mascot set to Giraffe (Ingrid's profile)! Which topic should we review?"
            }
        }

        btnLang.setOnClickListener {
            currentLangIndex = (currentLangIndex + 1) % languages.size
            updateUIForLanguage(txtResponse, inputQuery, btnSend, btnLang)
        }

        btnSend.setOnClickListener {
            val query = inputQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                val socraticReply = generateSocraticResponse(query, currentLangIndex)
                txtResponse.text = "[$currentMascot]:\n\n$socraticReply"
                inputQuery.text.clear()
            }
        }
    }

    private fun updateUIForLanguage(
        txtResponse: TextView,
        inputQuery: EditText,
        btnSend: Button,
        btnLang: Button
    ) {
        when (languages[currentLangIndex]) {
            "es" -> {
                btnLang.text = "🌐 ES"
                inputQuery.hint = "Escribe tu duda o tema aquí..."
                btnSend.text = "Preguntar al Coach (Guía Socrática)"
                txtResponse.text = "¡Hola! Soy tu tutor Socrático de Kawaii Study BCN (currículo LOMLOE). ¿Qué tema de Matemáticas, Historia o Ciencias quieres explorar hoy?"
            }
            "ca" -> {
                btnLang.text = "🌐 CA"
                inputQuery.hint = "Escriu el teu dubte o tema aquí..."
                btnSend.text = "Preguntar al Coach (Guia Socràtica)"
                txtResponse.text = "Hola! Sóc el teu tutor Socràtic de Kawaii Study BCN (currículum LOMLOE). Quin tema de Matemàtiques, Història o Ciències vols explorar avui?"
            }
            else -> {
                btnLang.text = "🌐 EN"
                inputQuery.hint = "Type your question or topic here..."
                btnSend.text = "Ask Coach (Socratic Guidance)"
                txtResponse.text = "Hello! I am your Socratic Study Coach for Kawaii Study BCN (LOMLOE syllabus). What Math, History, or Science topic would you like to explore today?"
            }
        }
    }

    private fun generateSocraticResponse(query: String, langIdx: Int): String {
        val qLower = query.lowercase()
        return when (languages[langIdx]) {
            "es" -> when {
                qLower.contains("mate") || qLower.contains("ecuacion") || qLower.contains("calcul") ->
                    "¡Buen reto matemático sobre '$query'! Antes de resolverlo, dime: ¿qué datos conocidos tenemos y cuál es exactamente la incógnita que buscamos?"
                qLower.contains("historia") || qLower.contains("barcelona") || qLower.contains("imperialismo") ->
                    "Interesante tema histórico: '$query'. Si analizamos las causas y consecuencias (como vemos en el temario de Barcelona/Cataluña), ¿qué factor económico o social crees que lo desencadenó?"
                else ->
                    "Gran pregunta sobre '$query'. Como tutor Socrático no te daré la solución directa: ¿qué pista o concepto previo de clase crees que se aplica aquí? ¡Dime tu primera idea!"
            }
            "ca" -> when {
                qLower.contains("mate") || qLower.contains("equacio") || qLower.contains("calcul") ->
                    "Bon repte matemàtic sobre '$query'! Abans de resoldre'l, digues: quines dades conegudes tenim i quina és exactament la incògnita que busquem?"
                qLower.contains("historia") || qLower.contains("barcelona") || qLower.contains("imperialisme") ->
                    "Interessant tema històric: '$query'. Si analitzem les causes i conseqüències (tal com es treballa al currículum de Catalunya), quin factor econòmic o social creus que ho va desencadenar?"
                else ->
                    "Molt bona pregunta sobre '$query'. Com a tutor Socràtic no et donaré la resposta directa: quina pista o concepte previ de classe creus que s'hi aplica? Explica'm la teva primera idea!"
            }
            else -> when {
                qLower.contains("math") || qLower.contains("equation") || qLower.contains("calc") ->
                    "Great math challenge on '$query'! Before solving it, tell me: what known values do we have, and what exact unknown are we trying to isolate?"
                qLower.contains("history") || qLower.contains("barcelona") || qLower.contains("imperialism") ->
                    "Fascinating history topic: '$query'. Looking at causes and consequences in your syllabus, which social or economic factor do you think triggered it?"
                else ->
                    "Thoughtful question about '$query'! As your Socratic coach, I won't just hand you the answer: what concept from your class notes do you think connects to this? Give me your first guess!"
            }
        }
    }
}
