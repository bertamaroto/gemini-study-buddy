import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

function buildSystemInstruction(student, subject, mode = 'coach') {
  const personaVibe =
    student === 'Olivia'
      ? 'Student is Olivia (Red Panda theme: playful, energetic, cozy, warm).'
      : student === 'Ingrid'
      ? 'Student is Ingrid (Giraffe theme: thoughtful, structured, curious, warm).'
      : 'Student is Guest (Cheerful Star theme: welcoming, adaptable, encouraging).';

  return `You are KawaiiStudy BCN, an expert, patient, encouraging AI study companion and Socratic tutor for teenagers in Barcelona, Spain.
${personaVibe}
Subject focus: ${subject || 'All subjects (Barcelona / Catalunya LOMLOE)'}.
Current mode: ${mode}.

CRITICAL LANGUAGE & CURRICULUM RULES:
1. Default primary language is English when starting fresh, UNLESS the student writes in Catalan or Spanish—always auto-detect the language the student uses (English, Catalan, or Spanish) and reply naturally in that exact same language. Switch seamlessly mid-chat if requested.
2. Strictly align all academic terminology, curriculum progressions, and exam prep (ESO, Batxillerat, Selectivitat / PAU) with the official Barcelona / Catalunya (LOMLOE) educational system (Departament d'Educació de la Generalitat de Catalunya / Gencat, Consorci d'Educació de Barcelona, and Ministerio de Educación y Formación Profesional).
3. Ground explanations in official institutional standards, most-cited academic authors/textbooks, and reputable universities. Wikipedia may be used for baseline facts only if unflagged/accurate. Reputable non-clickbait educational creators may be referenced for engaging analogies when cross-checked against academic standards.

STRICT SOCRATIC TUTORING RULES:
1. NEVER give direct homework answers, solve math equations outright, write essay paragraphs, or provide full translations.
2. Break complex problems into small, bite-sized steps and ask guiding questions or give hints so the student discovers the answer themselves.
3. Keep responses concise, warm, peer-like, and scannable (use short bullet points and relatable everyday analogies—no walls of text or lecturing).
4. Periodically check for understanding by asking the student to explain a concept back in their own words.`;
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, apiKeyConfigured: Boolean(apiKey) });
});

app.post('/api/chat', async (req, res) => {
  if (!ai) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY is not configured on the server. Add it in your hosting environment variables.',
    });
  }

  try {
    const { prompt, history = [], student, subject, mode } = req.body;
    const contents = Array.isArray(history) && history.length > 0
      ? history
      : [{ role: 'user', parts: [{ text: prompt || 'Hello!' }] }];

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents,
      config: {
        systemInstruction: buildSystemInstruction(student, subject, mode),
        tools: [{ googleSearch: {} }],
      },
    });

    res.json({ reply: response.text });
  } catch (error) {
    console.error('Gemini API Error:', error);
    res.status(500).json({ error: 'Failed to reach study companion. Check server logs and GEMINI_API_KEY.' });
  }
});

app.post('/api/generate-activity', async (req, res) => {
  if (!ai) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY is not configured on the server.',
    });
  }

  try {
    const { type, subject, topic, language = 'English', student } = req.body;
    const prompt =
      type === 'quiz'
        ? `Generate 3 multiple-choice quiz questions aligned with the Barcelona / Catalunya (LOMLOE) curriculum for subject "${subject || 'General'}"${topic ? ` on topic "${topic}"` : ''}. Write in ${language}. Return ONLY valid JSON (no markdown fences) in this exact format:
[{"question":"...","options":["A) ...","B) ...","C) ...","D) ..."],"correctIndex":0,"explanation":"..."}]`
        : `Generate 5 concise study flashcards aligned with the Barcelona / Catalunya (LOMLOE) curriculum for subject "${subject || 'General'}"${topic ? ` on topic "${topic}"` : ''}. Write in ${language}. Return ONLY valid JSON (no markdown fences) in this exact format:
[{"q":"...","a":"..."}]`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: buildSystemInstruction(student, subject, type),
      },
    });

    const raw = (response.text || '').replace(/```json|```/gi, '').trim();
    const items = JSON.parse(raw);
    res.json({ items });
  } catch (error) {
    console.error('Activity Generation Error:', error);
    res.status(500).json({ error: 'Could not generate study activity.' });
  }
});

// Fallback to index.html for SPA routes
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`KawaiiStudy BCN running on http://localhost:${PORT}`));
