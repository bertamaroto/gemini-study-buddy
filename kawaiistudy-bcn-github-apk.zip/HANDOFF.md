# Technical Handoff: KawaiiStudy BCN

## 1. Product Requirements, Personas & Behavioral Rules
* **Curriculum Alignment:** Strictly tuned to the official **Barcelona / Catalunya (LOMLOE)** curriculum across `Biologia i Geologia`, `Matemàtiques`, `Història`, `Llengua Catalana`, `Lengua Castellana`, and `English`.
* **Trilingual Auto-Detection:** Automatically detect whether the student writes in **Catalan, Spanish, or English** and reply in that exact same language.
* **Pedagogy & Grounding:** Guide students with Socratic questioning (never give away direct answers immediately) and use live Google Search grounding (`tools: [{ googleSearch: {} }]`) prioritizing reputable sources (Gencat, Consorci d'Educació de Barcelona, Ministerio de Educación, clean Wikipedia, top universities).
* **Multi-User Switcher:** Icon-only user pills in the sticky header (`Guest` 🐰 default, `Olivia` 🐼, `Ingrid` 🦒, plus `+` to add custom profiles).
* **UI & Navigation:** Mobile-first glassmorphic "kawaii" palette with bottom tab navigation (`Coach`, `Quiz`, `Cards`) and a bottom-right `Sources` modal for parents.

## 2. Included Fixes in This Bundle
1. **`sdkmanager` & Gradle Wrapper Fixes (`.github/workflows/build-apk.yml`):** Added `cmdline-tools-version: "11076708"` to `android-actions/setup-android@v3` and pinned `gradle wrapper --gradle-version 8.4`.
2. **Missing Android Resources Added:** Included `app/proguard-rules.pro` and adaptive launcher icon XMLs (`@mipmap/ic_launcher`, `@mipmap/ic_launcher_round`) so `./gradlew assembleDebug` compiles without resource linking errors.
3. **Full Web App (`server/`):** Restored the complete `server/public/index.html` (all 3 tabs, Catalan/Spanish/English topic pills, `Sources` modal) and `server/server.js` (with `googleSearch` grounding).

## 3. Remaining Step Before Release APK
* Deploy `server/` to a cloud host (e.g., Render or Railway) with `GEMINI_API_KEY` set, then replace `"https://your-kawaiistudy-bcn.onrender.com"` in `app/src/main/java/com/kawaiistudy/bcn/MainActivity.kt` with your live URL.
