# KawaiiStudy BCN

Interactive, trilingual (English / Español / Català) Socratic study coach aligned with the **Barcelona / Catalunya (LOMLOE)** curriculum.

## 1. Deploy the Backend & Web App (Required First)
The web app works in any mobile or desktop browser AND powers the Android APK.

1. Push this folder to your GitHub repository.
2. Create a free Web Service on **Render** (or Railway) connected to your GitHub repo (it will automatically detect `render.yaml`, or set **Root Directory** to `server`, **Build Command** to `npm install`, and **Start Command** to `npm start`).
3. Add environment variable: `GEMINI_API_KEY` = your Google AI Studio Gemini API key.
4. Once deployed, copy your live URL (e.g. `https://kawaiistudy-bcn.onrender.com`)—your teens can already use it directly in any browser!

## 2. Build the Android APK (Optional)
1. Open `app/src/main/java/com/kawaiistudy/bcn/MainActivity.kt` and replace `"https://your-kawaiistudy-bcn.onrender.com"` with your live Render URL.
2. Push to `main` on GitHub—GitHub Actions will automatically build `app-debug.apk` under the **Actions** tab.
