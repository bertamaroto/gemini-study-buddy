import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

app.post('/api/chat', async (req, res) => {
  try {
    const { prompt, student, subject } = req.body;

    const systemInstruction = `You are a patient, encouraging AI study companion for student ${student || 'Guest'}, tuned strictly to the official Barcelona / Catalunya (LOMLOE) curriculum.
    Subject focus: ${subject || 'General'}.
    Languages: Automatically detect whether the student writes in Catalan, Spanish, or English, and reply in that exact same language.
    Guidelines: Guide students using Socratic questioning, never give away direct answers immediately, prioritize reputable sources (Gencat, Consorci d'Educació de Barcelona, Ministerio de Educación, clean Wikipedia, top universities), and keep answers clear and age-appropriate.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
      },
    });

    res.json({ reply: response.text });
  } catch (error) {
    console.error('Gemini API Error:', error);
    res.status(500).json({ error: 'Failed to reach study companion.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`KawaiiStudy BCN running on http://localhost:${PORT}`));
