# KawaiiStudy BCN

Multi-user, trilingual AI study companion aligned with the Barcelona / Catalunya (LOMLOE) curriculum, powered by the Gemini API with live Google Search grounding.

## Quick Start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Set your Gemini API key:
   ```bash
   export GEMINI_API_KEY="your-api-key-here"
   ```
3. Start the server:
   ```bash
   npm start
   ```
4. Open `http://localhost:3000` in your browser or point your Android WebView APK to your hosted URL.
