const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Kawaii Study Server is running!' });
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
